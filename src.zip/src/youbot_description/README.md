youbot_description
==================

Robot description in form of URDF files and meshes
