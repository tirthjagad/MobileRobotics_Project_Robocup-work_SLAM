youbot_simulation
=================

Packages to run the KUKA youBot in the Gazebo simulation with ROS
