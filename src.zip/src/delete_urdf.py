import rospy 
import rospkg 
from geometry_msgs.msg import Pose,Point,Quaternion
from gazebo_msgs.srv import DeleteModel
from gazebo_msgs.srv import SpawnModel

def main():
    
    rospy.init_node('delete_urdf')

    
    rospy.wait_for_service("/gazebo/delete_model")
    
    try:
        delete_model = rospy.ServiceProxy("gazebo/delete_model", DeleteModel)
        
        delete_model("cube")
        delete_model("sphere")
        delete_model("sphere1")
    except rospy.ServiceException, e:
        print "Service call failed: %s" % e

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
